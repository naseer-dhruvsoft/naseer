document.addEventListener('DOMContentLoaded', function() {
    var link_success = document.getElementById('link_success');

	link_success.addEventListener('click', function() {
       document.getElementById('hide_success').style.display = 'none';
    });
});